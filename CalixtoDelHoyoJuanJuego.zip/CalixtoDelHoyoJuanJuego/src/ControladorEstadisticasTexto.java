import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.SwingUtilities;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
/*
 * Autores:
 * Juan Calixto del Hoyo
 * Ricardo Boza Villar
 */
public final class ControladorEstadisticasTexto {

    private final VistaEstadisticasTexto vista;
    private final CalculadoraEstadisticasTexto calculadora;
    private final ExecutorService ejecutor;

    public ControladorEstadisticasTexto(
            VistaEstadisticasTexto vista,
            CalculadoraEstadisticasTexto calculadora
    ) {
        this.vista = vista;
        this.calculadora = calculadora;
        this.ejecutor = Executors.newSingleThreadExecutor();
    }

    public void inicializar() {
        vista.getCampoTexto().getDocument().addDocumentListener(
                new DocumentListener() {
                    @Override
                    public void insertUpdate(DocumentEvent e) {
                        alCambiarTexto();
                    }

                    @Override
                    public void removeUpdate(DocumentEvent e) {
                        alCambiarTexto();
                    }

                    @Override
                    public void changedUpdate(DocumentEvent e) {
                        alCambiarTexto();
                    }
                }
        );
    }

    private void alCambiarTexto() {
        final String texto = vista.getCampoTexto().getText();

        ejecutor.submit(new Runnable() {
            @Override
            public void run() {
                final EstadisticasTexto estadisticas =
                        calculadora.calcular(texto);

                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        vista.mostrarEstadisticas(estadisticas);
                    }
                });
            }
        });
    }

    public void cerrar() {
        ejecutor.shutdownNow();
    }
}

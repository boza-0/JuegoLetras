import javax.swing.SwingUtilities;
/*
 * Autores:
 * Juan Calixto del Hoyo
 * Ricardo Boza Villar
 */
public final class Aplicacion {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                VistaEstadisticasTexto vista = new VistaEstadisticasTexto();
                CalculadoraEstadisticasTexto calculadora =
                        new CalculadoraEstadisticasTexto();
                ControladorEstadisticasTexto controlador =
                        new ControladorEstadisticasTexto(vista, calculadora);

                controlador.inicializar();
                vista.setVisible(true);
            }
        });
    }
}
